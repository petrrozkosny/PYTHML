import PyPDF2
from PyPDF2 import PdfReader, PdfWriter
import glob
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
import io

# Načíst všechny PDF
pdf_files = sorted(glob.glob("*.pdf"))
pdf_files = [f for f in pdf_files if not f.startswith("KOMPLETNI")]

writer = PdfWriter()
celkem_stran = 0

# Spojit všechny PDF
for pdf_file in pdf_files:
    reader = PdfReader(pdf_file)
    for page in reader.pages:
        writer.add_page(page)
        celkem_stran += 1

# Přidat výrazná čísla stránek
final_writer = PdfWriter()

for i in range(len(writer.pages)):
    page = writer.pages[i]
    cislo_stranky = i + 1

    # Vytvořit overlay s VELKÝM ČERNÝM číslem
    packet = io.BytesIO()
    page_width = float(page.mediabox.width)
    page_height = float(page.mediabox.height)

    c = canvas.Canvas(packet, pagesize=(page_width, page_height))

    # Bílý rámeček pod číslem (zakryje původní)
    c.setFillColorRGB(1, 1, 1)  # Bílá
    c.rect(page_width / 2 - 30, 12, 60, 30, fill=1, stroke=0)

    # VÝRAZNÉ ČERNÉ ČÍSLO
    c.setFillColorRGB(0, 0, 0)  # Černá
    c.setFont("Helvetica-Bold", 14)  # Velký tučný font
    c.drawCentredString(page_width / 2, 20, str(cislo_stranky))

    c.save()
    packet.seek(0)

    overlay_pdf = PdfReader(packet)
    page.merge_page(overlay_pdf.pages[0])
    final_writer.add_page(page)

# Uložit
with open("KOMPLETNI_FINAL.pdf", "wb") as f:
    final_writer.write(f)

print(f"Hotovo! Celkem {celkem_stran} stran")
print("Nová čísla jsou ČERNÁ, TUČNÁ a VELKÁ (18pt) dole uprostřed")
